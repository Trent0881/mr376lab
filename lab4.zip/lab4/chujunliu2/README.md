# chujunliu2

EECS476 assignment2 

## Example usage

## Running tests/demos
    
